//Global variables available in NMCLib.DLL:

__declspec(dllimport) HANDLE ComPort;
__declspec(dllimport) NMCMOD mod[]; 	//Array of modules
__declspec(dllimport) int SioError;
__declspec(dllimport) int IOBusy;
